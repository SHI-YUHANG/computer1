#define SERVER_IP_ADDR "127.0.0.1"  //服务器IP地址
#define SERVER_PORT 8000              //服务器端口号
#define BACKLOG 10
#define BUF_SIZE 1024
#define OK 1
#define ERROR 0
// #define SERVER_ROOT "/Users/shiyuhang/Desktop/code/computer_network"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>

const char* Server_name = "Server: Web Server 1.0 - BooLo\r\n";

int Server_Socket_Init();
int Handle_Request_Message(char* message, int Socket);
int Judge_URI(char* URI, int Socket);
int Send_Ifon(int Socket, const char* sendbuf, int Length);
int Error_Request_Method(int Socket);
int Inquire_File(char* URI);
int File_not_Inquire(int Socket);
int Send_File(char* URI, int Socket);
int Logo();
const char* Judge_Method(char* method, int Socket);
const char* Judge_File_Type(char* URI, const char* content_type);
const char* Get_Data(const char* cur_time);
const char* Post_Value(char* message);

char SERVER_ROOT[1024];


int Server_Socket_Init() {
    int ServerSock;
    struct sockaddr_in ServerAddr;

    /* 创建套接字 */
    ServerSock = socket(AF_INET, SOCK_STREAM, 0);
    if (ServerSock < 0) {
        perror("Failed to create socket");
        exit(1);
    }

    /* 配置服务器IP、端口信息 */
    memset(&ServerAddr, 0, sizeof(struct sockaddr));
    ServerAddr.sin_family = AF_INET;
    ServerAddr.sin_port = htons(SERVER_PORT);
    ServerAddr.sin_addr.s_addr = inet_addr(SERVER_IP_ADDR);

    /* 绑定 */
    if (bind(ServerSock, (struct sockaddr*)&ServerAddr, sizeof(struct sockaddr)) < 0) {
        perror("Failed to bind stream socket");
        exit(1);
    }

    return ServerSock;
}

int Handle_Request_Message(char* message, int Socket) {
	//处理HTTP请求报文信息 
	int rval = 0;
	char Method[BUF_SIZE];
	char URI[BUF_SIZE];
	char Version[BUF_SIZE];

	if (sscanf(message, "%s %s %s", Method, URI, Version) != 3) {
		printf("Request line error!\n");
		return ERROR;
	}	//提取"请求方法"、"URL"、"HTTP版本"三个关键要素 

	if (Judge_Method(Method, Socket) == ERROR) {
		return ERROR;
	}
	else if (strcmp(Judge_Method(Method, Socket), "POST") == 0) {
		Post_Value(message);
	}	//判断处理"请求方法" 

	if (Judge_URI(URI, Socket) == ERROR) {
		return ERROR;
	}	//判断处理"URI" 
	else
		rval = Send_File(URI, Socket);

	if (rval == OK) {
		printf("The process is successfully finished!\n");
	}

	return OK;
}

const char* Judge_Method(char* method, int Socket) {
	//判断请求方式 
	if (strcmp(method, "GET") == 0) {
		return "GET";
	}
	else if (strcmp(method, "POST") == 0) {
		return "POST";
	}
	else{
		Error_Request_Method(Socket);
		return ERROR;
	}
}

int Judge_URI(char* URI, int Socket) {
    char fullPath[BUF_SIZE];
    // 创建绝对路径
    snprintf(fullPath, sizeof(fullPath), "%s%s", SERVER_ROOT, URI);
    
    // 使用绝对路径代替原始URI来查找文件
    if (Inquire_File(fullPath) == ERROR) {
        File_not_Inquire(Socket);
        return ERROR;
    } else {
        return OK;
    }
}


int Send_Ifon(int Socket, const char* sendbuf, int Length) {
	//发送信息到客户端 
	int sendtotal = 0, bufleft, rval = 0;

	bufleft = Length;
	while (sendtotal < Length) {
		rval = send(Socket, sendbuf + sendtotal, bufleft, 0);
		if (rval < 0) {
			break;
		}
		sendtotal += rval;
		bufleft -= rval;
	}

	Length = sendtotal;

	return rval < 0 ? ERROR : OK;
}

int Error_Request_Method(int Socket) {
	//501 Not Implemented响应 
	const char* Method_err_line = "HTTP/1.1 501 Not Implemented\r\n";
	const char* cur_time = "";
	const char* Method_err_type = "Content-type: text/plain\r\n";
	const char* File_err_length = "Content-Length: 41\r\n";
	const char* Method_err_end = "\r\n";
	const char* Method_err_info = "The request method is not yet completed!\n";

	printf("The request method from client's request message is not yet completed!\n");

	if (Send_Ifon(Socket, Method_err_line, strlen(Method_err_line)) == ERROR) {
		printf("Sending method_error_line failed!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, Server_name, strlen(Server_name)) == ERROR) {
		printf("Sending Server_name failed!\n");
		return ERROR;
	}

	cur_time = Get_Data(cur_time);
	Send_Ifon(Socket, "Data: ", 6);
	if (Send_Ifon(Socket, cur_time, strlen(cur_time)) == ERROR) {
		printf("Sending cur_time error!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, Method_err_type, strlen(Method_err_type)) == ERROR) {
		printf("Sending method_error_type failed!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, Method_err_end, strlen(Method_err_end)) == ERROR) {
		printf("Sending method_error_end failed!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, Method_err_info, strlen(Method_err_info)) == ERROR) {
		printf("Sending method_error_info failed!\n");
		return ERROR;
	}

	return OK;
}

int Inquire_File(char* URI) {
	//查找文件 
	struct stat File_info;

	if (stat(URI, &File_info) == -1)
		return ERROR;
	else
		return File_info.st_size;
}

int File_not_Inquire(int Socket) {
	//404 Not Found响应 
	const char* File_err_line = "HTTP/1.1 404 Not Found\r\n";
	const char* cur_time = "";
	const char* File_err_type = "Content-type: text/plain\r\n";
	const char* File_err_length = "Content-Length: 42\r\n";
	const char* File_err_end = "\r\n";
	const char* File_err_info = "The file which is requested is not found!\n";

	printf("The request file from client's request message is not found!\n");

	if (Send_Ifon(Socket, File_err_line, strlen(File_err_line)) == ERROR) {
		printf("Sending file_error_line error!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, Server_name, strlen(Server_name)) == ERROR) {
		printf("Sending Server_name failed!\n");
		return ERROR;
	}

	cur_time = Get_Data(cur_time);
	Send_Ifon(Socket, "Data: ", 6);
	if (Send_Ifon(Socket, cur_time, strlen(cur_time)) == ERROR) {
		printf("Sending cur_time error!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, File_err_type, strlen(File_err_type)) == ERROR) {
		printf("Sending file_error_type error!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, File_err_length, strlen(File_err_length)) == ERROR) {
		printf("Sending file_error_length error!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, File_err_end, strlen(File_err_end)) == ERROR) {
		printf("Sending file_error_end error!\n");
		return ERROR;
	}

	if (Send_Ifon(Socket, File_err_info, strlen(File_err_info)) == ERROR) {
		printf("Sending file_error_info failed!\n");
		return ERROR;
	}

	return OK;
}

int Send_File(char* URI, int Socket) {
    char fullPath[BUF_SIZE];
    // 创建绝对路径
    snprintf(fullPath, sizeof(fullPath), "%s%s", SERVER_ROOT, URI);
    
	//200 OK响应 
	const char* File_ok_line = "HTTP/1.1 200 OK\r\n";
	const char* cur_time = "";
	const char* File_ok_type = "";
	const char* File_ok_length = "Content-Length: ";
	const char* File_ok_end = "\r\n";

	FILE* file;
	struct stat file_stat;
	char Length[BUF_SIZE];
	char sendbuf[BUF_SIZE];
	int send_length;

	if (Judge_File_Type(fullPath, File_ok_type) == ERROR) {
		printf("The request file's type from client's request message is error!\n");

		return ERROR;
	}

	file = fopen(fullPath, "rb");
    if (file != NULL) {
        fstat(fileno(file), &file_stat);
        sprintf(Length, "%ld", file_stat.st_size);  // 使用 sprintf 替代 itoa

        if (Send_Ifon(Socket, File_ok_line, strlen(File_ok_line)) == ERROR) {
            printf("Sending file_ok_line error!\n");
            return ERROR;
        }

		if (Send_Ifon(Socket, Server_name, strlen(Server_name)) == ERROR) {
			printf("Sending Server_name failed!\n");
			return ERROR;
		}

		cur_time = Get_Data(cur_time);
		Send_Ifon(Socket, "Data: ", 6);
		if (Send_Ifon(Socket, cur_time, strlen(cur_time)) == ERROR) {
			printf("Sending cur_time error!\n");
			return ERROR;
		}

		File_ok_type = Judge_File_Type(fullPath, File_ok_type);
		if (Send_Ifon(Socket, File_ok_type, strlen(File_ok_type)) == ERROR) {
			printf("Sending file_ok_type error!\n");
			return ERROR;
		}

		if (Send_Ifon(Socket, File_ok_length, strlen(File_ok_length)) != ERROR) {
			if (Send_Ifon(Socket, Length, strlen(Length)) != ERROR) {
				if (Send_Ifon(Socket, "\n", 1) == ERROR) {
					printf("Sending file_ok_length error!\n");
					return ERROR;
				}
			}
		}

		if (Send_Ifon(Socket, File_ok_end, strlen(File_ok_end)) == ERROR) {
			printf("Sending file_ok_end error!\n");
			return ERROR;
		}

		while (file_stat.st_size > 0) {
			if (file_stat.st_size < 1024) {
				send_length = fread(sendbuf, 1, file_stat.st_size, file);
				if (Send_Ifon(Socket, sendbuf, send_length) == ERROR) {
					printf("Sending file information error!\n");
					continue;
				}
				file_stat.st_size = 0;
			}
			else {
				send_length = fread(sendbuf, 1, 1024, file);
				if (Send_Ifon(Socket, sendbuf, send_length) == ERROR) {
					printf("Sending file information error!\n");
					continue;
				}
				file_stat.st_size -= 1024;
			}
		}
	}
	else {
		printf("The file is NULL!\n");
		return ERROR;
	}
	return OK;
}

const char* Judge_File_Type(char* URI, const char* content_type) {
    const char* suffix;

    if ((suffix = strrchr(URI, '.')) != NULL)
        suffix = suffix + 1;  // 获取文件后缀

    if (strcmp(suffix, "html") == 0 || strcmp(suffix, "htm") == 0) {
        return "Content-type: text/html\r\n";
    } else if (strcmp(suffix, "jpg") == 0 || strcmp(suffix, "jpeg") == 0) {
        return "Content-type: image/jpeg\r\n";
    } else if (strcmp(suffix, "png") == 0) {
        return "Content-type: image/png\r\n";
    } else if (strcmp(suffix, "gif") == 0) {
        return "Content-type: image/gif\r\n";
    } else if (strcmp(suffix, "txt") == 0) {
        return "Content-type: text/plain\r\n";
    } else if (strcmp(suffix, "mp3") == 0) {
        return "Content-type: audio/mpeg\r\n";
    } else if (strcmp(suffix, "pdf") == 0) {
        return "Content-type: application/pdf\r\n";
    } else {
        return ERROR;  // 如果不是上述已知类型，则返回NULL
    }
}


const char* Get_Data(const char* cur_time) {
	//获取Web服务器的当前时间作为响应时间 
	time_t curtime;
	time(&curtime);
	cur_time = ctime(&curtime);
	return cur_time;
}

const char* Post_Value(char* message) {
	//获取客户端POST请求方式的值 
	const char* suffix;
	
	if ((suffix = strrchr(message, '\n')) != NULL)
		suffix = suffix + 1;
	printf("\n\nPost Value: %s\n\n", suffix);
	return suffix;
}

int Logo() {
	//Web服务器标志信息 
	printf("___________________________________________________________\n");
	printf("            Welcome to use the Web Server!\n");
	printf("                     Version 1.0\n\n");
	printf("                         BooLo\n");
	printf("___________________________________________________________\n\n");
	return OK;
}

int main() {
    int ServerSock, MessageSock;
    struct sockaddr_in ClientAddr;
    int rval, Length;
    char revbuf[BUF_SIZE];

    getcwd(SERVER_ROOT, sizeof(SERVER_ROOT));
    Logo();
    ServerSock = Server_Socket_Init();

    while (OK) {
        /* 启动监听 */
        if (listen(ServerSock, BACKLOG) < 0) {
            perror("Failed to listen on socket");
            exit(1);
        }

        /* 接受客户端请求建立连接 */
        socklen_t Length = sizeof(struct sockaddr_in);
        MessageSock = accept(ServerSock, (struct sockaddr*)&ClientAddr, &Length);
        if (MessageSock < 0) {
            perror("Failed to accept connection from client");
            exit(1);
        }

        /* 接收客户端请求数据 */
        memset(revbuf, 0, BUF_SIZE);
        rval = recv(MessageSock, revbuf, BUF_SIZE, 0);
        if (rval <= 0) {
            perror("Failed to receive request message from client");
        } else {
            rval = Handle_Request_Message(revbuf, MessageSock);
        }
        close(MessageSock);
    }
    close(ServerSock);
    return OK;
}